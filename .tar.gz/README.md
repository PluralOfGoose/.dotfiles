# My Dotfiles
These are my dotfile configuration files for different software in Bash.
## .vimrc
This is my custom .vimrc configuration for Vim.
## .bashrc
This is my custom .bashrc configuration for Bash.

#Homework 2: In my git repository is two directories, bin and bash, as well as an ignore file, and a makefile. The gitignore file selects the files that are tracked, or rather those that are untracked by git. The bash directory holds two files, bashrc custom sets aliases and functions, and teh vimrc, which formats vim. The other directory, bin, holds two files: linux.sh, which checks that the operating system is linux, creates a TRASH directory, and changes the name of the vimrc in the home directory while refirecting errors to a seperate file. Lastly, the file overwrites the .vimrc in the home directory with the contents of the .vimrc in the bin directory. The cleanup file undoes all of the commands in the linux.sh file and removes the trash directory. The makefile targets linux and clean to run the linux.sh and clean.sh scritps, it then sets the execute permissions.


